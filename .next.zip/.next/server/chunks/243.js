exports.id = 243;
exports.ids = [243];
exports.modules = {

/***/ 9243:
/***/ ((module) => {

/*eslint-disable*/
module.exports = {
  messages: JSON.parse("{\"Buy, sell and collect NFTs.\":\"Buy, sell and collect NFTs.\"}")
};

/***/ })

};
;