exports.id = 679;
exports.ids = [679];
exports.modules = {

/***/ 9679:
/***/ ((module) => {

/*eslint-disable*/
module.exports = {
  messages: JSON.parse("{\"Buy, sell and collect NFTs.\":\"Buy, sell and collect NFTs.\"}")
};

/***/ })

};
;