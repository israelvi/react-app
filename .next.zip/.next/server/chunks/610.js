exports.id = 610;
exports.ids = [610];
exports.modules = {

/***/ 8610:
/***/ ((module) => {

/*eslint-disable*/module.exports={messages:JSON.parse("{\"Buy, sell and collect NFTs.\":\"Buy, sell and collect NFTs.\"}")};

/***/ })

};
;