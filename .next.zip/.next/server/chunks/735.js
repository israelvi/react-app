exports.id = 735;
exports.ids = [735];
exports.modules = {

/***/ 2735:
/***/ ((module) => {

/*eslint-disable*/module.exports={messages:JSON.parse("{\"Buy, sell and collect NFTs.\":\"Ćōmƥŕàŕ ŷ vēńďēŕ ŃƑŢś\"}")};

/***/ })

};
;