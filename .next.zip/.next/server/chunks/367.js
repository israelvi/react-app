exports.id = 367;
exports.ids = [367];
exports.modules = {

/***/ 6367:
/***/ ((module) => {

/*eslint-disable*/
module.exports = {
  messages: JSON.parse("{\"Buy, sell and collect NFTs.\":\"ßũŷ, śēĺĺ àńď ćōĺĺēćţ ŃƑŢś.\"}")
};

/***/ })

};
;