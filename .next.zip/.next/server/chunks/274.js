exports.id = 274;
exports.ids = [274];
exports.modules = {

/***/ 7274:
/***/ ((module) => {

/*eslint-disable*/module.exports={messages:JSON.parse("{\"Buy, sell and collect NFTs.\":\"Comprar y vender NFTs\"}")};

/***/ })

};
;